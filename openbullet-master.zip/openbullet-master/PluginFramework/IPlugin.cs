﻿namespace PluginFramework
{
    public interface IPlugin
    {
        string Name { get; }
    }
}
